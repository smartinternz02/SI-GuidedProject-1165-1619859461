#deployment 



import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
from gevent.pywsgi import WSGIServer
import os



app = Flask(__name__)
model = pickle.load(open('university.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
    #min max scaling
    min1=[290.0, 92.0, 1.0, 1.0, 1.0, 6.8, 0.0]
    max1=[340.0, 120.0, 5.0, 5.0, 5.0, 9.92, 1.0]
    k= [float(x) for x in request.form.values()]
    p=[]
    for i in range(7):
        l=(k[i]-min1[i])/(max1[i]-min1[i])
        p.append(l)
    prediction = model.predict([p])
    print(prediction)
    output=prediction[0]
    if(output==False):
        return render_template('nochance.html.html', prediction_text='You Dont have a chance')
    else:
        return render_template('chance.html.html', prediction_text='You have a chance')

port = os.getenv('VCAP_APP_PORT','8080')

if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=True, host = '0.0.0.0',port=port)